from datetime import datetime, timedelta
import json
from model import BsmAggregateDataModel, BsmAlertModel
from date_utility import parse_date

# load rules from config file
with open('config/alerts_config.json') as f:
    alerts_config = json.loads(f.read())


# function to check anomalies against the given rules
def check_anomaly(entry, rule):

    anomaly = {}
    anomaly['partition_id'] = entry['deviceid'] + " "+entry['datatype']
    anomaly['deviceid'] = entry['deviceid']
    anomaly['datatype'] = entry['datatype']
    anomaly['time_first_breach'] = entry['from_time']
    anomaly['avg_value'] = entry['avg_value']

    # check if value is below the normal range
    if entry['avg_value'] < rule['avg_min']:
        alert = 'is below the normal range [' + \
            str(rule['avg_min'])+','+str(rule['avg_max'])+']'
        anomaly['rule'] = alert
        anomaly['anomaly'] = 'below'
        return anomaly

    # OR

    # check if value is above the normal range
    elif entry['avg_value'] > rule['avg_max']:
        alert = 'is beyond the normal range [' + \
            str(rule['avg_min'])+','+str(rule['avg_max'])+']'
        anomaly['rule'] = alert
        anomaly['anomaly'] = 'beyond'
        return anomaly
    return None


# function to retrieve records from dynamodb
def get_records_within_time_range(from_time, to_time):
    bsm_agg_model = BsmAggregateDataModel()
    entries = bsm_agg_model.get_data_within_time_range(from_time, to_time)
    return entries


# function to detect anomalies
def find_amomalies(entries):
    anomalies = list()
    for entry in entries:
        rule = alerts_config[entry['datatype']]

        # check anomaly for the average value for this entry
        anomaly = check_anomaly(entry, rule)

        if anomaly is not None:
            anomalies.append(anomaly)
    return anomalies


# function to alert anomalies
def check_alerts(anomalies):
    alerts = []

    # IF ALERT FOR 5 CONSECUTIVE MINUTES THEN THROW ALERT
    devices = set(map(lambda r: r['deviceid'], entries))
    datatypes = set(map(lambda r: r['datatype'], entries))
    alert = {}
    print("\t", "Evaluated!")
    print("\t", "----------------")
    # process for each device ids for each sensor type
    for deviceid in devices:
        for datatype in datatypes:
            data = extract_data_per_device_datatype_wise(
                deviceid, datatype, anomalies)

            print("\t", deviceid, "-", datatype,  ":", len(data), "records")

            if len(data) > 0:
                alert_entries = check_trigger_count(data)
                if len(alert_entries) > 0:
                    alerts.extend(alert_entries)
    return alerts


# function to verify trigger count
def check_trigger_count(entries):

    # sort entries by time_stamp
    sorted_entries = sorted(
        entries, key=lambda item: item.get('time_first_breach'), reverse=False)

    alert_entries = list()
    first_breach = sorted_entries[0]
    trigger_count = 0
    index = 0
    for entry in sorted_entries:

        # if max count triggered; throw alert
        if trigger_count == alerts_config[entry['datatype']]['trigger_count']:
            alert_entries.append(first_breach)
            # Reset first breach with next entry
            first_breach = sorted_entries[index+1]
            trigger_count = 0
            continue

        # First check if the curent entry anomaly is same as the first breached anomaly at the corresponding timestamp;
        if first_breach['anomaly'] == entry['anomaly'] and parse_date(entry['time_first_breach']) == parse_date(first_breach['time_first_breach'])+timedelta(seconds=60)*trigger_count:
            trigger_count += 1
            index += 1
        else:
            # Current entry doesnot satisfy the previous anomaly
            # Reset first breach with current entry
            first_breach = sorted_entries[index+1]
            trigger_count = 0
            continue
    return alert_entries


# function to extract device records per sensor type
def extract_data_per_device_datatype_wise(deviceid, datatype, entries):
    data = list(
        filter(lambda x: x['deviceid'] == deviceid and x['datatype'] == datatype, entries))
    return data


# function to print alerts to console
def print_alerts(alerts):
    print(len(alerts), "alert(s) detected!")

    for alert in alerts:
        print(">", "[", alert['time_first_breach'], "]", alert['partition_id'], "- avg_value", alert['avg_value'],
              alert['rule'])

    print()


# function to save alerts to dynamodb
def save_alerts_to_dynamodb(alerts):
    bsm_alert_model = BsmAlertModel()
    bsm_alert_model.save_alerts(alerts)
    print("\t", len(alerts), 'record(s)')
    print("\t", 'Alerts saved successfully to dynamodb.')


# Main function
if __name__ == "__main__":

    # Please provide the input date range in "%Y-%m-%d %H:%M:%S.%f" format
    time_range_from = '2021-07-11 01:25:05.848261'  # user input
    time_range_to = '2021-07-11 02:25:05.848261'    # user input

    print()
    print("|*************************** RULES & ALERT **************************************|")
    print("\t", "Time range: [", time_range_from, ",", time_range_to, "]")
    # get data from dynamodb aggregation table with the given time range
    print()
    print("EXTRACTION")
    print("---------")
    print("\t", "Data extraction from dynamodb started....")
    entries = get_records_within_time_range(time_range_from, time_range_to)
    print("\t", "Retrieved: ", len(entries), "records")
    print("\t", "Data extraction complete!")

    # check against rule and detect anomalies
    anomalies = find_amomalies(entries)

    print()
    # print all alerts on the console
    print("CHECK ANOMALIES & ALERT")
    print("-----------------------")
    alerts = check_alerts(anomalies)

    print()
    # print alerts to console
    print_alerts(alerts)

    # save anomalies in dynamodb
    print("SAVE ALERTS TO DYNAMODB")
    print("-----------------------")
    save_alerts_to_dynamodb(alerts)
    print()
