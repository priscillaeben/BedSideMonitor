import datetime


DATE_FORMAT = "%Y-%m-%d %H:%M:%S.%f"


def parse_date(str_date):
    dt_object = datetime.datetime.strptime(str_date, DATE_FORMAT)
    return dt_object
