from database import Database
from boto3.dynamodb.conditions import Attr


class BsmDataModel:

    TABLE_NAME = 'BedSideMonitorData'            #Table Name we are using for Data Retrieval -- Publish Data Storage

    def __init__(self):
        self._db = Database()
        self.latest_error = ''

    def get_data_within_time_range(self, time_from, time_to):
        # build filter condition
        filter_expression = Attr('timestamp').between(time_from, time_to)
        items = self._db.find_by_time_range(
            BsmDataModel.TABLE_NAME, filter_expression)
        return items


class BsmAggregateDataModel:
    TABLE_NAME = 'bsm_agg_data'                #Table Name we are using to store aggregated Data

    def __init__(self):
        self._db = Database()
        self.latest_error = ''

    def save_aggregated_data(self, entries):
        print(entries)
        self._db.save_batch(BsmAggregateDataModel.TABLE_NAME, entries)

    def get_data_within_time_range(self, time_from, time_to):
        # build filter condition
        filter_expression = Attr('from_time').between(time_from, time_to)
        items = self._db.find_by_time_range(
            BsmAggregateDataModel.TABLE_NAME, filter_expression)
        return items


class BsmAlertModel:
    TABLE_NAME = 'bsm_alert'

    def __init__(self):
        self._db = Database()
        self.latest_error = ''

    def save_alerts(self, entries):
        self._db.save_batch(BsmAlertModel.TABLE_NAME, entries)
