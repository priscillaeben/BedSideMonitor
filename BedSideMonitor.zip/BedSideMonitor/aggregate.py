import datetime
from date_utility import parse_date


class Aggregator:
    def __init__(self):
        pass

    def aggregate_data(self, entries, time_window, delta):
        '''
        Main function to aggregate data by device id and sensor type.
        Find min,max and avg.
        '''
        # get all available device_ids
        sensor_types = set(self.__get_sensor_types(entries))

        # get all available device_ids
        device_ids = set(self.__get_device_ids(entries))

        aggregated_data = []
        # process for each device ids for each sensor type
        for device_id in device_ids:
            for sensor_type in sensor_types:
                data = self.__process_data_per_device_sensor_type_wise(
                    device_id, sensor_type, entries, time_window, delta)
                print(device_id, "-", sensor_type,  ":", len(data), "records")
                aggregated_data.extend(data)
        return aggregated_data

    # sensor specific data processing for each device
    def __process_data_per_device_sensor_type_wise(self, device_id, sensor_type, entries, time_window, delta):
        data = self.__extract_data_per_device_sensor_type_wise(
            device_id, sensor_type, entries)

        # loop here for the whole lot of time-range data
        time_delta = datetime.timedelta(seconds=delta)
        start_time = parse_date(time_window[0])
        end_time = parse_date(time_window[1])

        aggregated_data = []
        while start_time < end_time:
            time_from = start_time
            time_to = time_from+time_delta  # time window of 1 minute

            processed_data = self.__process(
                data, time_from, time_to)

            if processed_data is not None:
                # add device id field to aggregated data
                processed_data['deviceid'] = device_id

                # add sensor type field to aggregated data
                processed_data['datatype'] = sensor_type

                # populate each aggregated entry
                aggregated_data.append(processed_data)

            # for remaining lot of data based on time delta
            start_time = time_to
        return aggregated_data

    # extract data by sensor type for a device
    def __extract_data_per_device_sensor_type_wise(self, device_id, sensor_type, entries):
        data = list(
            filter(lambda x: x['deviceid'] == device_id and x['datatype'] == sensor_type, entries))
        return data

    # find all unique device ids
    def __get_device_ids(self, entries):
        devices = map(lambda r: r['deviceid'], entries)
        return devices

    # find all unique sensor types
    def __get_sensor_types(self, entries):
        sensor_types = map(lambda r: r['datatype'], entries)
        return sensor_types

   # Main Processing
    def __process(self, entries, from_time, to_time):

        if entries is None:
            return None

        # loop over the given time range and filter out data
        filtered_data = list(filter(lambda v: parse_date(v['timestamp']) >=
                                    from_time and parse_date(v['timestamp']) < to_time, entries))
        # if empty filtered set
        if len(filtered_data) == 0:
            return None

        # find min,max,avg
        analysed_data = self.__analyse(filtered_data)

        analysed_data['from_time'] = str(from_time)
        analysed_data['to_time'] = str(to_time)

        return analysed_data

    # calculate min,max,avg
    def __analyse(self, entries):
        values = {}
        sensor_values = []
        for entry in entries:
            # build partition key
            values['partition_id'] = entry['deviceid'] + \
                " "+entry['datatype']
            # list out all sensor values
            sensor_value = entry['value']
            sensor_values.append(sensor_value)

        values['min_value'] = min(sensor_values)
        values['max_value'] = max(sensor_values)
        values['count'] = len(sensor_values)
        values['avg_value'] = round(
            sum(sensor_values)/values['count'], 2)

        return values
