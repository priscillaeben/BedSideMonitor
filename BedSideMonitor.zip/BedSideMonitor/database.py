import boto3
from boto3.dynamodb.conditions import Attr
from datetime import datetime


class Database:

    def __init__(self):
        # Get the service resource.
        self._dynamodb = boto3.resource('dynamodb')

    def find_by_time_range(self, table_name, filter_expression):
        table = self._dynamodb.Table(table_name)
        response = table.scan(
            FilterExpression=filter_expression
        )
        items = response["Items"]
        return items

    def save_batch(self, table_name, entries):
        table = self._dynamodb.Table(table_name)
        with table.batch_writer() as batch:
            for entry in entries:
                if entry is not None:
                    entry['CurrentTime'] = str(
                        datetime.now())  # add current timestamp
                    batch.put_item(Item=entry)
