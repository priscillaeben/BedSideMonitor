from model import BsmAggregateDataModel, BsmDataModel
from aggregate import Aggregator


# function to retrieve data from dynamodb
def ingest_data(time_window):
    time_range_from = time_window[0]
    time_range_to = time_window[1]

    bsmData = BsmDataModel()
    data = bsmData.get_data_within_time_range(time_range_from, time_range_to)
    return data


if __name__ == "__main__":

    # Please provide the input date range in "%Y-%m-%d %H:%M:%S.%f" format
    time_range_from = '2021-07-11 01:25:05.848261'  # user input
    time_range_to = '2021-07-11 02:25:05.848261'    # user input

    # As per project requirement 1 minute interval
    time_delta = 60  # seconds

    print()
    print("********************** Data Retrieval *********************************")
    print("Time range: [", time_range_from, ",", time_range_to, "]")
    print("Data retrieval from dynamodb started....")
    # create time range tuple for easy passing as arguments
    time_window = (time_range_from, time_range_to)

    # retrieve data from DynamoDB within the given time range
    data_to_be_processed = ingest_data(time_window)
    print("Retrieved: ", len(data_to_be_processed), "records")
    print("Data retrieval complete!")
    print()

    # aggregate data
    print("********************** Data Aggregation *********************************")
    print("Data aggregation started....")
    print("Interval: ", time_delta, " seconds")
    print()
    aggregator = Aggregator()
    processed_data = aggregator.aggregate_data(
        data_to_be_processed, time_window, time_delta)
    print("Aggregation complete!")
    print()

    # save aggregated data
    print("******************* Aggregated Data Insertion ****************************")
    print("Data insertion started....")
    bsm_agg_model = BsmAggregateDataModel()
    bsm_agg_model.save_aggregated_data(processed_data)
    print('Total records:', len(processed_data))
    print('Data successfully saved in dynamodb!')
    print()
